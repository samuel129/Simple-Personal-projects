dic = {"dog":100, "cat":1001}
print(dic.index(100))